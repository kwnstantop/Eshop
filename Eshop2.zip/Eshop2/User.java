public class User
{
    private String usname;//onoma xristi
    private String usemail;//email xristi
    
    //dimiourgos User
    public User(String usname,String usemail)
    {
        this.usname=usname;
        this.usemail=usemail;
    }
    
    //kenos dimiourgos 
    public User()
    {
        
    }
    
    //setters
    public void setusname(String usname)
    {
        this.usname=usname;
    }
    
    //getters
    public String getusname()
    {
        return usname;
    }
    
    public String userinfo() throws Exception//epistrefei ws mhnyma to onoma kai to email tou xristi
    {
        return "Onoma xristi: "+usname+"Email xristi: "+getUsemail();
    }

	public String getUsemail() {
		return usemail;
	}

	public void setUsemail(String usemail) {
		this.usemail = usemail;
	}
}
