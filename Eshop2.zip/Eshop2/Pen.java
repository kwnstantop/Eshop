public class Pen extends Item//i klasi Pen klironomei tin iperklasi Item
{
    protected String color;//xrwma Pen
    protected double tipSize;//megethos mitis Pen se mm
    

    
    public Pen(String name,double price,String description,int stock,int id,String color,double tipSize)
    {
        super(name,price,description,stock,id);
        this.color=color;
        this.tipSize=tipSize;
    }
    
    public String getDetails()//polimorfismos:orizoume diaforetika thn  getDetails() ap oti stis alles ipoklaseis tis Item
    {
        return "to xrwma tou pen einai:"+color+"\n to megethos tis mitis tou pen se mm einai:"+tipSize;
    }
    
    public String toString()//h methodos auth kalei k epistrefei tis 2 
    //proigoumenes methodous,getBasicInfo() k getDetails()
    {
        return "\n oi vasikes plirofories einai: \n"+getBasicInfo()+"\n oi leptomeries tou proiontos einai: \n"+getDetails();
    }
}
