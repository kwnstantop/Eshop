import java.util.*;
import java.io.*;
public class Menu
{
    EShop eshop = new EShop();//stigmiotipo eshop
    Scanner scanner = new Scanner(System.in);
    public void Main() throws Exception {
        while(true) {
            System.out.println("Welcome to my shop!");
            System.out.println("Press {O} if you are an Owner, and press {B} if you are a Buyer ");
            String choice =  scanner.nextLine();//eisagei o xristis String metavliti
            switch(choice){
                case "B":
                    System.out.println(EShop.buyersList);
                    System.out.println("Please enter your email: ");
                        String ch1 =  scanner.nextLine();//o buyer eisagei email
                        Iterator<Buyer> iterator1 = EShop.buyersList.iterator();//iterator gia prospelash listas buyer
                        while(iterator1.hasNext()) {
                            Buyer b = iterator1.next();
                            if (b.getUsemail().equals(ch1)) {
                                System.out.println("User found, welcome back");
                                System.out.println(b.userinfo());//tupwsi stoixeiwn buyer
                                ShoppingCart shop = new ShoppingCart();
                                //shop.showCart(b);
                                while(true) {
                                    System.out.println("!#$%^&**&^%$#@!@#$%^&**&^%$#@!@#$%^&*)");
                                    System.out.println("Press 1 to browse the store");
                                    System.out.println("Press 2 to view Cart");
                                    System.out.println("Press 3 to Checkout");
                                    System.out.println("Press 4 togo one step back");
                                    System.out.println("Press 5 to Logout/Change User");
                                    System.out.println("Press 6 to EXIT");
                                    System.out.println("!#$%^&**&^%$#@!@#$%^&**&^%$#@!@#$%^&*)");
                                    int ch = scanner.nextInt();//eisagei arithmo gia na epileksei leitourgia
                                    switch(ch) {
                                    case 1 :
                                        eshop.showProductsInCategory();//h show in category perilamvanei kai thn show categories, h opoia paraleiptetai
                                        eshop.showProduct();
                                        System.out.println("Do you want to buy it?(Y/N)");
                                        String cha = scanner.toString();
                                        switch(cha) {
                                        case "Y":
                                            b.placeOrder(null);//kaleitai h placeOrder gia ton xristi b
                                        default:
                                            System.out.println("Too bad!");
                                        break;
                                        }
                                    case 2 :
                                    
                                        shop.showCart();
                                    case 3 :
                                      shop.checkout();   
                                    case 6:
                                        System.out.println("Thank you for visiting");
                                        System.exit(0);
                                        break;
                                    }
                            }
                            }
                            else {
                                System.out.println("No user found!Do you want to sign up?(Y/N) ");
                                ch1 =  scanner.nextLine();
                                if(ch1.equals("Y"))
                                    eshop.addBuyer(null);
                                else
                                    System.out.println("K BOOMER!");
                            }
                            break;
                    }
                
                case "O":
                    Iterator<Owner> iterator2 = EShop.ownersList.iterator();
                    System.out.println("Please enter your email: ");
                    String ch2 =  scanner.nextLine();
                    while(iterator2.hasNext()) {
                         Owner owner = iterator2.next();
                         if (owner.getUsemail().equals(ch2) ) {
                             System.out.println("Welcome back,owner 🙂 ");
                             System.out.println(owner.userinfo());//tupwsi stoixeiwn owner
                             while(true) {
                                 System.out.println("!#$%^&**&^%$#@!@#$%^&**&^%$#@!@#$%^&*)");
                                 System.out.println("Press 1 to browse the store");
                                 System.out.println("Press 2 to check item details");
                                 System.out.println("Press 3 to go back");
                                 System.out.println("Press 4 to Logout/Change User");
                                 System.out.println("Press 5 to EXIT");
                                 
                                 System.out.println("!#$%^&**&^%$#@!@#$%^&**&^%$#@!@#$%^&*)");
                                 int ch11 = scanner.nextInt();//eisagei arithmo gia na epileksei leitourgia
                                 switch(ch11) {
                                    case 1 :
                                        eshop.showProductsInCategory();//h show in category perilamvanei kai thn show categories, h opoia paraleiptetai
                                        eshop.showProduct();
                                        System.out.println("Do you want to change item stock?(Y/N)");
                                        String ch22 = scanner.toString();
                                        if(ch22 == "Y")
                                            eshop.updateItemStock();//kaleitai h updateItemStock gia ton owner
                                        else
                                            break;
                                    case 2 :
                                           eshop.checkStatus();
                                            System.out.println(EShop.buyersList);
                                            System.out.println("Please enter buyers email: ");
                                            String ch3 =  scanner.nextLine();
                                            Iterator<Buyer> iterator3 = EShop.buyersList.iterator();//iterator gia prospelash listas buyer
                                            while(iterator3.hasNext()) {
                                                Buyer b2 = iterator3.next();
                                                if (b2.getUsemail().equals(ch3)) {
                                                	eshop.removeBuyer(b2);
                                    
                                                		
                                    }
                             }
 
                         }
                    }
            }
        }
    }
   }
}
}