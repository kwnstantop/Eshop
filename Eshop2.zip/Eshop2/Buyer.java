import java.util.Scanner;

public class Buyer extends User//h klasi buyer klironomei thn uperklasi User
 {
	Scanner scanner = new Scanner(System.in);//me thn Scanner kanoume eisagwgh metavlitwn apo to pliktrologio
	private int bonus;//bonus tou pelath
	final String field1 = "BRONZE";//katigoria xristi
	final String field2 = "SILVER";//katigoria xristi
	final String field3 = "GOLD";//katigoria xristi
	private boolean payedorder;
    String buyerCategory;

	ShoppingCart shop1 = new ShoppingCart();
	
	public Buyer(String usname,String usemail,int bonus)
    {
        super(usname,usemail);
        this.bonus=bonus;
    }
    
    public Buyer()//kenos constructor buyer
    {
    }
    public void setbonus(int bonus)
    {
        this.bonus=bonus;
    }
    
    public int getbonus()
    {
        return bonus;
    }

    public int awardBonus() throws Exception//methodos pou orizei to bonus tou pelath
    {
        if (payedorder=true)//h boolean metavliti payedorder otan einai true,auksanei to bonus tou buyer
        {
           bonus= bonus+1;
        }
        else
            System.out.println("Order payment failed.");
       return bonus;
    }
    
    public String setbuyerCategory(int bonus)
    //me vash to bonus tou buyer,epistrefete to category pou anhkei
    {
    	if (bonus < 100) {
    		buyerCategory = field1;
    		return buyerCategory;
    	}
    	if ( bonus>= 100 && bonus < 200) {
    		buyerCategory = field2;
    		//return buyerCategory;
    	}
    	if ( bonus >= 200) {
    		buyerCategory = field3;
    		//return buyerCategory;
    	}
    	return buyerCategory;
    }
    public String getbuyerCategory()
    {
        return buyerCategory;
    }
    
    public void placeOrder(ItemOrdered it1) throws Exception //methodos pou prosthetei item sthn paragelia
    {
    	if(it1 == null) //an to antikeimeno it1 einai keno mpainei sthn if kai ektelei entoles!
    	{
    		System.out.println("Confirm the ID: ");
    		int id = scanner.nextInt();//eisagwgi int kwdikou apo to pliktrologio
    		System.out.println("Give desired Quantity: ");
    		int quant = scanner.nextInt();//eisagwgi plithous antikeimenou apo to pliktrologio
    		shop1.AddItemOrdered(id,quant);//prosthiki antikeimenou sthn paraggelia
    		payedorder = true;
    	}
    	else
    		shop1.AddItemOrdered(it1.getItemId(),it1.getQuantity());
    		payedorder = true;   
    }
    public String userinfo() throws Exception //tipwnei stoixeia tou buyer!
    {
        return "To bonus tou buyer einai:"+ bonus + "\nTo category tou buyer einai: "+ buyerCategory +"\nMail: "+getUsemail() + "\nOnoma: "+ getusname();
    }

}
