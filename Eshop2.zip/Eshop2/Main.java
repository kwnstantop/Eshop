public class Main {
    public static void main(String[] args) throws Exception {
        EShop eshop = new EShop();//object eshop
        ShoppingCart shop = new ShoppingCart();//object shoppingcart
        System.out.println("Welcome!!");
        Menu menu = new Menu();//object menu
        
        Pen blpen = new Pen("BLUE PEN",1.5,"It is a blue pen",112,111,"Blue",1.0);//stigmiotipo b1pen tipou Pen me times
        eshop.addItem(blpen);//prosthiki b1pen stigmiotipou
        EShop.pensList.add(blpen);//prosthiki b1pen stigmiotupou sto pensList
        EShop.pens++;
        Pen rpen = new Pen("RED PEN",1.3,"It is a red pen",123,112,"Red",1.0);//stigmiotipo tipou Pen me times
        eshop.addItem(rpen);
        EShop.pensList.add(rpen);//prosthiki rpen stigmiotipou sto pensList
        EShop.pens++;
        Pen bpen = new Pen("BLACK PEN",1.3,"It is a black pen",121,113,"Black",1.0);//dimiourgia stigmiotipou tupou Pen me times
        eshop.addItem(bpen);
        EShop.pensList.add(bpen);//prosthiki bpen sto pensList
        EShop.pens++;
        //dimiourgia stigmiotupwn tipou Pencil me times kai prosthiki tous sto pencilsList
        Pencil hpencil = new Pencil("H PENCIL",1.2,"It is a H pencil", 123,121,0.5,"H");
        eshop.addItem(hpencil);
        EShop.pencilsList.add(hpencil);
        EShop.pencils++;
        Pencil bpencil = new Pencil("B PENCIL",1.3,"It is a B pencil", 122,122,0.7,"B");
        eshop.addItem(bpencil);
        EShop.pencilsList.add(bpencil);
        EShop.pencils++;
        Pencil hbpencil = new Pencil("HB PENCIL",1.5,"It is a HB pencil", 1243,123,1.0,"HB");
        eshop.addItem(hbpencil);
        EShop.pencilsList.add(hbpencil);
        EShop.pencils++;
        //dimiourgia stigmiotupwn tipou Notebook me times kai prosthiki tous sto notebooksList
        Notebook simple = new Notebook("Simple Volume Notebook",1,"It only has one section",121,131,1);
        eshop.addItem(simple);
        EShop.notebooksList.add(simple);
        EShop.notebooks++;
        Notebook  dual = new Notebook("Dual Volume Notebook",1.7,"It has two sections",141,132,2);
        eshop.addItem(dual);
        EShop.notebooksList.add(dual);
        EShop.notebooks++;
        Notebook triple = new Notebook("Triple Volume Notebook",2.3,"It has three sections",145,133,3);
        eshop.addItem(triple);
        EShop.notebooksList.add(triple);
        EShop.notebooks++;
        //dimiourgia stigmiotupwn tipou Paper me times kai prosthiki tous sto papersList
        Paper a4 = new Paper("Pack Of A4 Papers",8.0,"1000 pages of A4 paper",111,131,4,1000);
        eshop.addItem(a4);
        EShop.papersList.add(a4);
        EShop.papers++;
        Paper a3 = new Paper("Pack Of A3 Papers",10.0,"1000 pages of A3 paper",31,132,8,1000);
        eshop.addItem(a3);
        EShop.papersList.add(a3);
        EShop.papers++;
        Paper a2 = new Paper("Pack Of A2 Papers",12.0,"1000 pages of A2 paper",61,133,16,1000);
        eshop.addItem(a2);
        EShop.papersList.add(a2);
        EShop.papers++;
        
        Owner owner = new Owner("Owner","owner@owner.owner");//dimiourgia stigmiotipou owner
        EShop.ownersList.add(owner);//prosthiki owner se lista
        //dimiourgia pelatwn kai prosthiki tous ws Buyer,orismos tou category tous me set sunartisi
        Buyer takis = new Buyer("Buyer1","buyer1@buyer.com",102);
        takis.setbuyerCategory(102);
        eshop.addBuyer(takis);
        Buyer kounela = new Buyer("Buyer2","buyer2@buyer.com",311);
        kounela.setbuyerCategory(311);
        eshop.addBuyer(kounela);


        
        ItemOrdered takisorder1 = new ItemOrdered(blpen,4);
        ItemOrdered takisorder2 = new ItemOrdered(bpencil,17);
        try {
            //klisi tis placeOrder gia kataxwrisi twn paraggeliwn
            takis.placeOrder(takisorder1);
            takis.placeOrder(takisorder2);
        } catch (Exception e) {
            System.out.println("Something went wrong...");
            e.printStackTrace();//xrhsh tou printStackTrace gia entopismo sfalmatos mesa sto try catch!
        }
        

        
        //dimiourgia stigmiotipwn tipou Itemordered
        ItemOrdered kounela1 = new ItemOrdered(a4,13);
        ItemOrdered kounela3 = new ItemOrdered(a3,2);
        try {
            //klisi tis placeOrder gia kataxwrisi twn paraggeliwn
            kounela.placeOrder(kounela1);
            kounela.placeOrder(kounela3);
        } catch (Exception e) {

            e.printStackTrace();//methodos gia entopismo lathous
        }
        
        //eshop.addBuyer();
        eshop.checkStatus();//klisi tis checkStatus gia to stigmiotipo eshop
        menu.Main();
        
        
    }
}
