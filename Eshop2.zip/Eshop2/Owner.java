public class Owner extends User//i klasi Owner klirwnomei thn klasi User
{
    private boolean isAdmin=true;
    
    public Owner(String usname,String usemail)
    {
        super(usname,usemail);
        
    }
    
    public void setisAdmin(boolean isAdmin)
    {
        this.isAdmin=isAdmin;
    }

    public boolean getisAdmin()
    {
        return this.isAdmin;
    }
    
    public String userinfo() throws Exception//ipervash ths userinfo()
    {
        return super.userinfo();
    }
}
