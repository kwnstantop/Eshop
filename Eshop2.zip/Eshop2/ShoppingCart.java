import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Scanner;

public class ShoppingCart 
{
	
    private int nextOrderId = 1 ;
    private BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    Scanner scanner=new Scanner(System.in);
	static ArrayList<ItemOrdered> orderedList=new ArrayList<ItemOrdered>();//array pinakas orderedList,xrhsh array dioti mporoume na prosthesoume kai na afairesoume stoixeia
	ItemOrdered ordered = new ItemOrdered();//dimiourgia object ordered tupou ItemOrdered
    
    
   //kenos constructor ShoppingCart
    public ShoppingCart()
    {
    }
    public void AddItemOrdered(int id , int quantity) {
    	Iterator<Item> iterator = EShop.itemsList.iterator();//dilwsi iterator gia prospelash stoixeiwn ena pros ena
    	while( iterator.hasNext()) {
    		Item item = iterator.next();
    		if (item.id == id)//elegxoume an to id tou item einai idio me to id pou ekane eisagwgi o xristis
    		{
    			if (item.stock < quantity)//gia  posothta proiontos mikroterh ths posothtas pou thelei o xristis
    			{
    				System.out.println("Not enough stock");
    				return;
    			}
    			else {
    				ItemOrdered ordered = new ItemOrdered(item,quantity);
    				System.out.println("Order placed, "+ ordered.getQuantity() + " " + item.getName() + "  added to the cart");
    	    		ordered.setordId(nextOrderId);
    				orderedList.add(ordered);//prosthiki object sto orderedList
    				//System.out.println("Please note the id: "+ ordered.toString());
    				item.stock = item.stock - quantity;//enhmerwsh stock tou item
    				nextOrderId++;
    				break;
    			}
    		}
    		
    	}
    }
    //already exist .(exists)?
    
    	
    	public void addItemOrdered()throws Exception{//add item pou mporw na eisagw proion me input apo to pliktrologio 
	          
	    		System.out.println("Enter product id: ");
		    	    int id = Integer.parseInt(input.readLine());
		    	    Iterator<Item> iterator = EShop.itemsList.iterator();
		    	   	while( iterator.hasNext()) {
		    	   		Item item = iterator.next();
		    	    		
		    	   		if(item.id == id) {
		    	   			System.out.print("Enter desired quantity: ");
		    	   			int quan = Integer.parseInt(input.readLine());
		    	   			if(quan <= item.stock) {
		    	    			ItemOrdered ordered = new ItemOrdered(item,quan);
		    	    			ordered.setordId(nextOrderId);
		    	    			orderedList.add(ordered);
		    	    			System.out.println("Order placed, "+ ordered.getQuantity() + " " + item.getName() + "  added to the cart");
		    	    			item.stock = item.stock - quan;
		    	    			nextOrderId++;
		    	    		}
		    	    		else {System.out.print("Sorry,not enough stock \n");}
		    	    	}
		    	    	else {
		    	    		System.out.print("Sorry,either the item you typed is non existent \n");
		    	    	}
		          }     
        }
    public void  calculateNet() //h calculateNet() epistrefei thn aksia mias paraggelias
    {
    	Iterator<Item> iterator = EShop.itemsList.iterator();//me ton iterator trexoume ta stoixeia ths listas ena pros ena
    	Iterator<ItemOrdered> iterator2 = orderedList.iterator();
    	while( iterator.hasNext()) {
    		Item item = iterator.next();
    		double cost = item.price * ordered.quantity; 
    		System.out.println("Your order costs: " + cost);
			
		}
	}

		
	public void changeItemOrderedQuantity() throws Exception
	{
		for (ItemOrdered ordered : orderedList)//me thn enhanced for loop,kanoyme epanalipsi gia ola ta stoixeia tis listas ths parakatw entoles 
		{
			int b;
			System.out.println("Give me your order id: ");
			int scan = Integer.parseInt(input.readLine());//eisagwgh id paragelias apton xristi
	        System.out.println(scan);//ektipwsi ths timis pou eisagame
	        if(scan == ordered.getordId()) {
	            System.out.println(ordered.getQuantity());
	            b=scanner.nextInt();//eisagoume timi apo pliktrologio
	            ordered.setQuantity(b);//allazoume to orisma tis quantity se b me thn sunartisi set
	            System.out.println("Stock updated!");
	            System.out.println(ordered.toString());//tipwsi stoixeiou ordered
	        }
	        else{
	            System.out.println("Desired item not found");
	        }
	    }
	}

	
	
    public void showCart() //tipwsi stoixeiwn paraggelias
    {
    		System.out.println(orderedList);
    }
    public void clearCart() {
    	orderedList.clear();
    }
    
    
    public void removeItemOrdered() throws Exception//methodos pou afairei stoixeio ths ordererdList mesw tou id tou
    {
    	
		System.out.println("================");
		System.out.print("Enter order id: ");
		int id = Integer.parseInt(input.readLine());

		for (ItemOrdered ordered : orderedList) {
			if (ordered.getordId() == id) {
				orderedList.remove(ordered);//afairoume apo to arraylist orderedList to stoixeio ordered
				System.out.println("Item removed from order: " + orderedList);//tipwsi twn enapomeinentwn stoixeiwn ths listas
				break;
			}
		}
	}

public void checkout(){
    	showCart();
    	System.out.println("Sure you want to complete order?(Y/N)");
    	String choice =  scanner.nextLine();
    	if(choice == "Y")
    		clearCart();
    	else
    		System.out.println("Ok, transaction not complete");
    }
}