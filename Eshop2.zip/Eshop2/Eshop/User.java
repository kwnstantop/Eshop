public class User
{
    private String usname;//onoma xristi
    private String usemail;//email xristi
    
    //dimiourgos User
    public User(String usname,String usemail)
    {
        this.usname=usname;
        this.usemail=usemail;
    }
    
    //kenos dimiourgos me default times
    public User()
    {
        usname="No name";
        usemail="No email";
    }
    
    //setters
    public void setusname(String usname)
    {
        this.usname=usname;
    }
    
    public void setusemail(String usemail)
    {
        this.usemail=usemail;
    }
    
    //getters
    String getusname()
    {
        return usname;
    }
    
    String getusemail()
    {
        return usemail;
    }
    
    public String userinfo()//epistrefei ws mhnyma to onoma kai to email tou xristi
    {
        return "Onoma xristi: "+usname+"Email xristi: "+usemail;
    }
}
