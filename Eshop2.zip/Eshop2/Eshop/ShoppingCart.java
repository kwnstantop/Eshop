import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Scanner;

public class ShoppingCart 
{
    
    private int nextOrderId = 1 ;
    private BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    Scanner scanner=new Scanner(System.in);
    ArrayList<ItemOrdered> orderedList=new ArrayList<ItemOrdered>();//array pinakas orderedList,xrhsh array dioti mporoume na prosthesoume kai na afairesoume stoixeia
    Iterator<Item> iterator = EShop.itemsList.iterator();
    ItemOrdered ordered = new ItemOrdered();
    
    
   //kenos constructor ShoppingCart
    public ShoppingCart()
    {
    }
    //already exist .(exists)?
    public void addItemOrdered() throws Exception {
        Iterator<Item> iterator = EShop.itemsList.iterator();
        
        System.out.println("Enter product id: ");
        int id = Integer.parseInt(input.readLine());//eisagoume int stoixeio apo to pliktrologio
        while( iterator.hasNext())//xrhsimopoioume iterator gia na diatreksoume ta stoixeia tou itemsList ena pros ena
        {
            Item item = iterator.next();
            
            if(item.id == id)//elegxoume an to id tou item einai idio me to id pou ekane eisagwgi o xristis
            {
                System.out.print("Enter desired quantity: ");
                int quan = Integer.parseInt(input.readLine());//eisagei o xristis thn posothta tou item pou thelei na paraggeilei
                if(quan <= item.stock) {
                    ItemOrdered ordered = new ItemOrdered(item,quan);
                    ordered.setordId(nextOrderId);//me thn sunarthsh set,allazoume thn timh thn metavliti tis ordId
                    orderedList.add(ordered);
                    System.out.println("Order placed,here is the info (please note the id): "+ ordered.toString());
                    item.stock = item.stock - quan;//enhmerwsh stock proiontos sthn item
                    nextOrderId++;
                }
                else {System.out.print("Sorry,not enough stock \n");}
            }
            else {
                System.out.print("Sorry,either the item you typed is non existent \n");
            }
        }
    }
    public void  calculateNet()//h calculateNet() epistrefei thn aksia mias paraggelias
    {
        Iterator<Item> iterator = EShop.itemsList.iterator();//me ton iterator trexoume ta stoixeia ths listas ena pros ena
        while( iterator.hasNext()) {
            Item item = iterator.next();
            double cost = item.price * ItemOrdered.getQuantity();
            System.out.println("Your order costs: " + cost);
        }
    }

    public void changeItemOrderedQuantity() throws Exception
    {
        for (ItemOrdered ordered : orderedList)//me thn enhanced for loop,kanoyme epanalipsi gia ola ta stoixeia tis listas ths parakatw entoles 
        {
            int b;
            System.out.println("Give me your order id: ");
            int scan = Integer.parseInt(input.readLine());//eisagwgh id paragelias apton xristi
            System.out.println(scan);
            if(scan == ordered.getordId()) {
                System.out.println(ordered.getQuantity());
                b=scanner.nextInt();
                ordered.setQuantity(b);//allazoume to orisma tis quantity se b me thn sunartisi set
                System.out.println("Stock updated!");
                System.out.println(ordered.toString());//tipwsi stoixeiou ordered
            }
            else{
                System.out.println("Desired item not found");
            }
        }
    }

    
    
    public void showCart() //tipwsi stoixeiwn paraggelias,
    {
            System.out.println(orderedList);
    }
    public void clearCart() {
        orderedList.clear();
    }
    
    
    public void removeItemOrdered() throws Exception {
        
        System.out.println("================");
        System.out.print("Enter order id: ");
        int id = Integer.parseInt(input.readLine());

        for (ItemOrdered ordered : orderedList) {
            if (ordered.getordId() == id) {
                orderedList.remove(ordered);//afairoume apo to arraylist orderedList to stoixeio ordered
                System.out.println("Item removed from order: " + orderedList);//tipwsi pinaka orderedList
                break;
            }
        }
    }
}



