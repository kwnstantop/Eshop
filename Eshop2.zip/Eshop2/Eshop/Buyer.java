import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
public class Buyer extends User//h klasi buyer klironomei thn uperklasi User
{
    private int bonus=0;
    private String buyerCategory;
    private int totalbuyers=0;
    private boolean payedorder;
    private BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
    ArrayList<Buyer> buyerscategory=new ArrayList<Buyer>();
    String BRONZE,SILVER,GOLD;
    
    public Buyer(String usname,String usemail,int bonus)
    {
        super(usname,usemail);
        this.bonus=bonus;
    }
    
    public Buyer()//kenos constructor buyer
    {
        super();
        bonus=0;
        totalbuyers++;
    }
    
    public void setbonus(int b)
    {
        this.bonus=b;
    }
    
    public int getbonus()
    {
        return bonus;
    }
    
    public int gettotalbuyers()
    {
        return totalbuyers;
    }
    
    public void awardBonus() throws Exception
    {
        if (payedorder=true)
        {
            bonus++;
            System.out.println("Enter buyerCategory(BRONZE,SILVER OR GOLD");
            String buyerCategory = input.readLine();
        }
        else
            System.out.println("Order payment failed.");
       
    }
    
   
    public void setbuyerCategory(String BRONZE)//me vash to bonus tou buyer,epistrefete to category pou anhkei
    {
        for (Buyer buyer : buyerscategory)
        if (bonus == 0 && bonus < 100)
        { System.out.println("This buyer category is BRONZE!");
            //setbuyerCategory(BRONZE);
            
        }
        else if (bonus == 100 && bonus < 200)
        {
            System.out.println("This buyer category is SILVER!");
            setbuyerCategory(SILVER);
        }
        else if (bonus >= 200)
        {
            System.out.println("This buyer category is GOLD!");
            setbuyerCategory(GOLD);
        }
    }
    
    public String getbuyerCategory()
    {
        return buyerCategory;
    }
    
    
    public void placeOrder() throws Exception
    {
    	ItemOrdered it1 = new ItemOrdered();
    	ShoppingCart shop1 = new ShoppingCart();
    	shop1.addItemOrdered();
        
        
        
    }
    
    public String userinfo()//tipwnei stoixeia tou buyer!
    {
        return super.userinfo()+"To bonus tou buyer einai:"+ getbonus() + "To category tou buyer einai:"+ getbuyerCategory();
    }
}


