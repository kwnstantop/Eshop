import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Scanner;
    
public class Menu
{
    public static void main(String[] args) throws Exception {
        EShop eshop = new EShop();
        ShoppingCart cart = new ShoppingCart();
        Buyer buyer1 = new Buyer("Ben","ben@bensmail.com",163);
        eshop.AddBuyer(buyer1);

        Pen pen = new Pen("name",1.5,"It is a pen",112,1111,"Red",1.0);
        eshop.AddItem(pen);
        System.out.println("Welcome to my shop!");
       while(true){ 
           Scanner shop = new Scanner(System.in);
           System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
           System.out.println("press 1 to add item");
           System.out.println("press 2 to search item by id");
           System.out.println("press 3 to show products in a specific category");
           System.out.println("press 4 to remove item");
           System.out.println("press 5 to see what items we currently have");
           System.out.println("press 6 to update an item stock");
           System.out.println("press 7 to add order");
           System.out.println("press 8 to change order quantity");
           System.out.println("press 9 to see cart");
           System.out.println("press 10 to remove order");
           
           
           System.out.println("press 11 to exit ");
           String dialekse = shop.nextLine();
           switch(dialekse){
            case "1":
                eshop.addItem();
                break;
            case "2":
                eshop.getItemById();
                break;
            case "3":
                eshop.showProductsInCategory();
                break;
            case "4":
                eshop.showProduct();
                break;
            case "5":
                buyer1.placeOrder();
                break;
            case "6":
                eshop.updateItemStock();
                break;
            case "7":
                cart.addItemOrdered();
                break;
            case "8":
                cart.changeItemOrderedQuantity();
                break;
            case "9":
                cart.showCart();
                break;   
            case "10":
                eshop.test();
                break;
            case "12":
                eshop.checkStatus();
                break;
                
            case "11":
                System.exit(0);
                break;
                
            default:
                System.out.println("nice typing");
           
            }
       }
  
    }
}
