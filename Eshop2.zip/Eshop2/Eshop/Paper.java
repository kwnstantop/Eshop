public class Paper extends Item//h klasi paper klironomei tin klasi Item
{
   protected int weight;//varos paper se grammaria
   protected int pages;//arithmos sellidwn
   
   //dimiourgos tis Paper
   public Paper(String name,double price,String description,int stock,int id,int w,int p)
   {
       super(name,price,description,stock,id);
       weight=w;
       pages=p;
   }
   
   public String getDetails()//polimorfismos:orizoume diaforetika thn  getDetails() ap oti stis alles ipoklaseis tis Item
    {
        return " to varos tou xartiou se grammaria einai:"+weight+"\n o arithmos twn sellidwn einai:"+pages;
    }
}
