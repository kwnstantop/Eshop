import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Scanner;
    
public class EShop
{
        // instance variables - replace the example below with your own
     static ArrayList<Item> itemsList = new ArrayList<Item>();//array pinakas itemsList
     static ArrayList<User> buyersList = new ArrayList<User>();//array pinakas buyersList
     private BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
     int totalitems=0;
     //dimiourgia objects,tipou Item kai Buyer
     Item item=new Item(); 
     Buyer buyer=new Buyer();
     Buyer b1 = new Buyer();
     Scanner sc=new Scanner(System.in);
     private int pens, pencils, notebooks, papers;
     private boolean buyerAlreadyExists;

     
       //=kenos cunstructor Eshop
       public EShop()
       {
       }
       
       public ArrayList<Item> getList()
       {
           return itemsList;
       }
        
       public ArrayList<User> getbuyersList()
       {
           return buyersList;
        }
       public void AddItem(Item item){// 2h add item wste na topothetountai stigmiotipa apo thn main 
    	   itemsList.add(item);
       }
       
      public void addItem(){//add item pou mporw na eisagw proion me input apo to pliktrologio 
        try{
            Scanner scanner = new Scanner(System.in);
            System.out.println("What product do you want to add?");
            System.out.println("Press 1 for Pen");
            System.out.println("Press 2 for Pencil");
            System.out.println("Press 3 for Notebook");
            System.out.println("Press 4 for Paper");
            String product = scanner.nextLine();//methodos pou den dexetai orisma
            
            System.out.print("Enter product name: ");
            String name = input.readLine();//eisagwgi String metavlitis mesw pliktrologiou
            System.out.print("Enter product price: ");
            int price = Integer.parseInt(input.readLine());//eisagwgi int metavlitis mesw pliktrologiou
            System.out.print("Enter product description: ");
            String description = input.readLine();//eisagwgh String metavlitis mesw pliktrologiou
            System.out.print("Enter product stock: ");
            int stock = Integer.parseInt(input.readLine());//eisagwgi int metavlitis mesw pliktrologiou
            System.out.print("Enter product ID: ");
            int id = Integer.parseInt(input.readLine());//eisagwgi int metavlitis mesw pliktrologiou
            
            switch (product){
                case "1":
                    
                    System.out.print("Enter product color: ");
                    String color = input.readLine();//eisagwgi String metavlitis gia to xrwma mesw pliktrologiou
                    System.out.print("Enter product tip size: ");
                    Double tipSize = Double.parseDouble(input.readLine());//eisagwgh tip size tipou double mesw pliktrologiou
                    
                    item = new Pen(name,price,description,stock,id,color,tipSize);
                    Item pen = this.item;
                    itemsList.add(item);//prosthiki item ston array pinaka itemsList
                    System.out.println(" ");
                    System.out.println("Added new Pen: \n" + item.toString());//tipwsi stoixeiwn item
                    break;
                    
                case "2":
                    
                    System.out.print("Enter product tip size: ");
                    Double tipsize = Double.parseDouble(input.readLine());//eisagwgh tip size tipou double mesw pliktrologiou
                    System.out.print("Enter product type(H,B or HB): ");
                    String type = input.readLine();//eisagwgh tupou pen  string mesw pliktrologiou
                    
                    item = new Pencil(name,price,description,stock,id,tipsize,type);
                    itemsList.add(item);//prosthiki item sto itemsList
                    System.out.println(" ");
                    System.out.println("Added new Pencil: \n" + item.toString());//tipwsi pliroforiwn tou item
                    break;
                    
                case "3":
                    System.out.print("Enter product sections: ");
                    int sections = Integer.parseInt(input.readLine());//eisagei o xristis int stoixeio apto pliktrologio
                    
                    item = new Notebook(name,price,description,stock,id,sections);
                    itemsList.add(item);//prosthiki se itemsList to stoixeio item
                    System.out.println(" ");
                    System.out.println("Added new Notebook: \n" + item.toString());
                    break;
                    
                case "4":
                    System.out.print("Enter product weight: ");
                    int weight = Integer.parseInt(input.readLine());//eisagei o xristis int stoixeio apto pliktrologio
                    System.out.print("Enter product pages: ");
                    int pages = Integer.parseInt(input.readLine());//eisagei o xristis int stoixeio apto pliktrologio
                    
                    item = new Paper(name,price,description,stock,id,weight,pages);
                    itemsList.add(item);//prosthiki se itemsList to stoixeio item
                    System.out.println(" ");
                    System.out.println("Added new Notebook: \n" + item.toString());
                    break;
                    
                
                
                default:
                    System.out.println("INVALID TYPE OF PRODUCT!!!");//minima lathous,se periptwsh lathous tupou item
            }
            
            
            
        }catch (IOException e)//to IOException otan o xristis dwsei lathos tipo input
        {
            System.out.println("Something went wrong.");
        }
            
        
    }
    
        
    public void getItemById() throws Exception
        {
        System.out.println("Give me the ID of the desired product");
        int scan = Integer.parseInt(input.readLine());
       
        System.out.println(scan);
        if(scan == item.getid())//an to id pou edwse o xristis einai idio me to id enos item,tipwnontai oi plirofories tou item
        {
            System.out.println(item.toString());
            
        }
        else{
            System.out.println("No item");//minama sfalmatos
        }
   
        }
        
    public void removeItem() //me thn removeItem() tha afairoume ena proion me vash to id tou.
        throws Exception
        {
            System.out.println("================");
            System.out.print("Enter product id: ");
            int id = Integer.parseInt(input.readLine());//eisagei o xristis int stoixeio apo to pliktrologio
            
            int itemIndex=-1;
            
            for (int i=0;i<itemsList.size();i++){
                Item item=itemsList.get(i);
                
                if (item.getid() == id)//an to id pou eisagei o xristis tautizetai me to id enos item,to item afaireitai apo to itemsList
                {
                    itemIndex = i;
                    break;
                }
                
                
		        }
		        if (itemIndex == -1)//h timi -1 einai endeiksi lathous!
		        {
		            System.out.println("Item with given id wasn't found");
		        }
		        else{
		                itemsList.remove(itemIndex);
		                System.out.println("Item removed");
		         }
	    } 
    public void AddBuyer(User b1) // add buyer mesw main
        {
    		buyersList.add(b1);//prosthiki sigkekrimenou buyer sthn buyersList
        }
    		

    public void addBuyer() throws Exception // add buyer me input
    {
            System.out.print("Enter Buyer username: ");
            String usname = input.readLine();   //eisagetai to onoma tou Buyer 
            System.out.print("Enter Buyer user email: ");
            String usemail = input.readLine(); //eisagetai to email tou Buyer
            System.out.print("Enter Buyer bonus: ");
            int bonus = Integer.parseInt(input.readLine());//eisagetai to bonus tou Buyer
            
            buyer = new Buyer(usname,usemail,bonus);
            buyersList.add(buyer);
           /** if (buyerAlreadyExists=false)//an h boolean metavliti buyerAlreadyExist einai false tote prosthetoume ton xristi sto buyersList
                buyersList.add(buyer);
            else
                System.out.println("This is not a new Buyer!");  */
    }
    
    public void removeBuyer() throws Exception
    {
        System.out.print("Enter Buyer username: ");
        String usname = input.readLine();  //eisagwgh onomatos buyer apo to pliktrologio 
        System.out.print("Enter Buyer user email: ");
        String usemail = input.readLine(); //eisagwgi email buyer apo to pliktrologio
        System.out.print("Enter Buyer bonus: ");
        int bonus = Integer.parseInt(input.readLine());//eisagwgi bonus buyer apo to pliktrologio
        
        buyer = new Buyer();
        if (buyerAlreadyExists=true)//an o buyer uparxei,tote afaireitai apo to buyersList
            buyersList.remove(buyer);
        else
            System.out.println("This buyer does not exist,can not remove !");
    }
        
        
     public void updateItemStock() throws Exception
     {
    	 for(Item item : itemsList) {
            int a;
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Give me the ID of the desired product");
            int scan = Integer.parseInt(input.readLine());
           
            if(scan == item.getid()){
                System.out.println("The current stock is: "+item.getstock());
                System.out.println("Type the new Stock: ");
                a=sc.nextInt();//eisagoume timi a apo to pliktrologio
                item.setstock(a);//enhmerwnoyme to stock mesw ths sunarthshs setstock.
            }
            else{
                System.out.println("Desired item not found");
            }
    	 }
     }
        
        public void showCategories()//h showCategories() emfanizei tis katigories proiontwn tou katastimatos
        {
        System.out.println(" ");
        System.out.println("Our store currently has: ");
        if(pens !=0)
            System.out.println("Pens ");
        if(pencils !=0)
            System.out.println("Pencils ");    
        if(notebooks !=0)
            System.out.println("Notebooks ");
        if(papers !=0)
            System.out.println("Papers ");
    
    }
    
    public void showProductsInCategory()//h showProductsInCategory() emfanizei ta proionta ana katigoria
    {
            Scanner sc = new Scanner(System.in);
            System.out.println("What kind of product do you want to see?");
            System.out.println("Press 1 for Pen");
            System.out.println("Press 2 for Pencil");
            System.out.println("Press 3 for Notebook");
            System.out.println("Press 4 for Paper");
            System.out.println(" ");
            String cat = sc.nextLine();
            
            
            switch(cat){
               case"1":
               
                   System.out.println("Pens:");
                   for (Item pen: itemsList)
                   {
                       System.out.println(pen.toString());//tipwsh olwn twn stoixeiwn pen ths itemsList

                    }
                    break;
               case"2":
               
                   System.out.println("Pencils:");
                   for (Item pencil: itemsList) {
                       System.out.println(pencil.toString());//tipwsi olwn twn stoixeiwn pencil ths itemsList

                    }
                    break;
               case"3":
               
                   System.out.println("Notebooks:");
                   for (Item notebook: itemsList) {
                       System.out.println(notebook.toString());//tipwsi olwn twn stoixeiwn notebook ths ietmsList

                    }
                    break;
               case"4":
               
                   System.out.println("Papers:");
                   for (Item paper: itemsList) {
                       System.out.println(paper.toString());//tipwsi olwn twn stoixeiwn paper tis itemsList

                    }
                    break;
               default:
               System.out.println("Sorry, wrong type!");//minima sfalmatos
            }
        }
        
    public void showProduct() throws Exception
    {
        for (Item item : itemsList)
            getItemById();//kaleitai h getItemById gia kathe stoixeio item ths itemsList
    }
    public void test() {
    	for (User b1 : buyersList)
            System.out.println(buyersList);//tipwsh ths buyersList
    }
      
    public void checkStatus() 
    {
        for (User b1 : buyersList)
            System.out.println("Oi buyers einai:"+getbuyersList());
            System.out.println(b1.userinfo());//kaleitai h userinfo() gia ton xristi b1.
            
    }
}

        