public class Pencil extends Item//i klasi Pencil klironomei tin iperklasi Item
{
    private double tipSize;//miti pencil se mm
    private String type;
    
    //dimiourgos Pencil
    public Pencil(String name,double price,String description,int stock,int id,double tipSize,String type)
    {
        super(name,price,description,stock,id);
        this.tipSize=tipSize;
        this.type=type;
    }
    
    public String getDetails()//polimorfismos:orizoume diaforetika thn  getDetails() ap oti stis alles ipoklaseis tis Item
    {
        return "to megethos tis mitis tou pen se mm einai:"+tipSize+"\n O  tipos moliviou einai:"+type;
    }
   
}


