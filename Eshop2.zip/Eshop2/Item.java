public class Item
{
    String name;//onoma proiontos
    double price;//timi proiontos se evrw
    String description;//perigrafi proiontos
    int stock;//diathesimotita proiontos
    int id;//kwdikos proiontos
    
    //dimiourgos Item
    public Item(String name,double price,String description,int stock,int id)
    {
        this.name=name;
        this.price=price;
        this.description=description;
        this.stock=stock;
        this.id=id;
        
    }
    public Item()//kenos constructor item
    {
    }
    
    //getter
    public static Item getItem(int id)//epistrofh statikou melous Item me orisma to id tou.
    {
        Item item=new Item("",0,"",0,0);//dimiourgia item typou Item,me default orismata
        
        return item;
    }
    public String getName() {
    	return name;
    }
    
    public void setid(int id)
    {
        this.id=id;
    }
    
    public int getid()
    {
        return id;
    }
    
    public void setstock(int stock)
    {
        this.stock=stock;
    }
    
    public int getstock()
    {
        return stock;
    }
    
    public String getBasicInfo()//methodos getBasicInfo epistrefei ws String mesage tis metavlites enos Item
    {
        return "Onoma proiontos:"+name+"\n Timi proiontos:"+price+"\n Perigrafi proiontos:"+description+"\n Diathesimotita proiontos:"+stock+"\n Kwdikos proiontos:"+id;
    }
    
    public String getDetails()//h getDetails methodos epanaorizetai stis paragwmenes klaseis tis Item,sthn Item tha epistrefei keno minima!
    {
        return "";
    }
    
    //@ovveride
    public String toString()//h methodos auth kalei k epistrefei tis 2 
    //proigoumenes methodous,getBasicInfo() k getDetails()
    {
        return "oi vasikes plirofories einai:"+getBasicInfo()+"\n oi leptomeries tou proiontos einai:"+getDetails();
    }
    
}

