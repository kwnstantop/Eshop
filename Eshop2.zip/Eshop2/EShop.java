import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;
import java.util.Scanner;
    
public class EShop
{
        // instance variables - replace the example below with your own
     static ArrayList<Item> itemsList = new ArrayList<Item>();//array pinakas itemsList
     static ArrayList<Item> pensList = new ArrayList<Item>();//array pinakas pensList
     static ArrayList<Item> pencilsList = new ArrayList<Item>();//array pinakas pencilsList
     static ArrayList<Item> notebooksList = new ArrayList<Item>();//...
     static ArrayList<Item> papersList = new ArrayList<Item>();//..
     
     static ArrayList<Buyer> buyersList = new ArrayList<Buyer>();//array pinakas buyersList
     static ArrayList<Owner> ownersList = new ArrayList<Owner>();//...
     private BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
     
     Item item=new Item(); //dimiourgia object item type Item
     Buyer buyer=new Buyer();//dimiourgia object buyer type Buyer
     Buyer b1 = new Buyer();//dimiourgia object b1 type Buyer
     Scanner sc=new Scanner(System.in);
     public static int pens, pencils, notebooks, papers;
     private boolean buyerAlreadyExists;
     private int  counter=0;
     private boolean breaker = true;
 
     
       //instance of 
       public EShop()
       {
       }
       
       public ArrayList<Item> getList()
       {
           return itemsList;
       }
        
       public ArrayList<Buyer> getbuyersList()
       {
           return buyersList;
        }
       
      public void addItem(Item item){//add item pou mporw na eisagw proion me input apo to pliktrologio 
       if(item == null) {
	    	  try{
	            Scanner scanner = new Scanner(System.in);
	            System.out.println("What product do you want to add?");
	            System.out.println("Press 1 for Pen");
	            System.out.println("Press 2 for Pencil");
	            System.out.println("Press 3 for Notebook");
	            System.out.println("Press 4 for Paper");
	            String product = scanner.nextLine();//methodos pou den dexetai orisma
	            
	            System.out.print("Enter product name: ");
	            String name = input.readLine();//eisagwgi String metavlitis mesw pliktrologiou
	            System.out.print("Enter product price: ");
	            int price = Integer.parseInt(input.readLine());//eisagwgi int metavlitis mesw pliktrologiou
	            System.out.print("Enter product description: ");
	            String description = input.readLine();//eisagwgi String metavlitis mesw pliktrologiou
	            System.out.print("Enter product stock: ");
	            int stock = Integer.parseInt(input.readLine());//eisagwgi int metavlitis mesw pliktrologiou
	            System.out.print("Enter product ID: ");
	            int id = Integer.parseInt(input.readLine());//eisagwgi int metavlitis mesw pliktrologiou
	            
	            switch (product){
	                case "1":
	                    
	                    System.out.print("Enter product color: ");
	                    String color = input.readLine();
	                    System.out.print("Enter product tip size: ");
	                    Double tipSize = Double.parseDouble(input.readLine());
	                    
	                    item = new Pen(name,price,description,stock,id,color,tipSize);
	                    itemsList.add(item);//prosthiki item ston array pinaka itemsList
	                    pensList.add(item);//prosthiki item ston array pinaka pensList
	                    System.out.println(" ");
	                    System.out.println("Added new Pen: \n" + item.toString());//tipwsi pliroforiwn tou item
	                    pens++;
	                    break;
	                    
	                case "2":
	                    
	                    System.out.print("Enter product tip size: ");
	                    Double tipsize = Double.parseDouble(input.readLine());
	                    System.out.print("Enter product type(H,B or HB): ");
	                    String type = input.readLine();
	                    
	                    item = new Pencil(name,price,description,stock,id,tipsize,type);
	                    itemsList.add(item);
	                    pencilsList.add(item);
	                    System.out.println(" ");
	                    System.out.println("Added new Pencil: \n" + item.toString());
	                    pencils++;
	                    break;
	                    
	                case "3":
	                    System.out.print("Enter product sections: ");
	                    int sections = Integer.parseInt(input.readLine());
	                    
	                    item = new Notebook(name,price,description,stock,id,sections);
	                    itemsList.add(item);
	                    notebooksList.add(item);
	                    System.out.println(" ");
	                    System.out.println("Added new Notebook: \n" + item.toString());
	                    notebooks++;
	                    break;
	                    
	                case "4":
	                    System.out.print("Enter product weight: ");
	                    int weight = Integer.parseInt(input.readLine());
	                    System.out.print("Enter product pages: ");
	                    int pages = Integer.parseInt(input.readLine());
	                    
	                    item = new Paper(name,price,description,stock,id,weight,pages);
	                    papersList.add(item);
	                    System.out.println(" ");
	                    System.out.println("Added new Notebook: \n" + item.toString());
	                    papers++;
	                    break;
	                    
	                
	                
	                default:
	                    System.out.println("INVALID TYPE OF PRODUCT!!!");
	                    
	            }
	            
	            
	            
	        }catch (IOException e) {
	            System.out.println("Something went wrong.");}
            
       }
       else
    	   itemsList.add(item);
    }
    
        
    public void getItemById() throws Exception
        {
    	if(breaker = true) {
    		System.out.println("Give me the ID of the desired product");
    		int scan = Integer.parseInt(input.readLine());
    		//for(Item item : itemsList)
        		if(scan == item.getid()){
        			System.out.println(item.toString());
        			breaker=false;
        			//break;
        		}	
        		else {
        			breaker=false;
        		}
        			//break;
    	}
    	
    	
    		
        }
        
    public void removeItem() //me thn removeItem() tha afairoume ena proion me vash to id tou.
        {
            System.out.println("================");
            System.out.print("Enter product id: ");
            int id;
			try {
				id = Integer.parseInt(input.readLine());
				 int itemIndex=-1;
		            
		            for (int i=0;i<itemsList.size();i++){
		                Item item=itemsList.get(i);
		                
		                if (item.getid() == id)
		                {
		                    itemIndex = i;
		                    itemsList.remove(itemIndex);
		                    System.out.println("Item removed");
		                    break;
		                }
		                
		                
				        }
				        if (itemIndex == -1)//h timi -1 einai endeiksi lathous!
				        {
				            System.out.println("Item with given id wasn't found");
				        }
				        else{
				         
				                System.out.println("Item with given id wasn't found");
				         }
			} catch (NumberFormatException | IOException e) {
				e.printStackTrace();
			}
            
           
	    } 

    		

    public void addBuyer(Buyer b1) throws Exception // add buyer me input
    {
    	if(b1 == null) {
    	    //eisagoyme stoixeia ston b1 buyer
    		System.out.print("Enter Buyer username: ");
            String usname = input.readLine();   
            System.out.print("Enter Buyer user email: ");
            String usemail = input.readLine(); 
            System.out.print("Enter Buyer bonus: ");
            int bonus = Integer.parseInt(input.readLine());
            
            buyer = new Buyer(usname,usemail,bonus);
            buyer.setbuyerCategory(bonus);//allazoume category buyer me xrhsh ths set
            buyersList.add(buyer);//prosthiki buyer sto buyersList
            System.out.println("Added new Buyer: \n" + buyer.userinfo());
    	}
    	else {
    		buyersList.add(b1);
    	}
           
    } 
    
  
     public void removeBuyer(Buyer b) 
    {
    	if(b == null)
    		System.out.print("Enter Buyer username: ");
    		try {
    			String usname = input.readLine();//eisagoume String onoma
    		} catch (IOException e) {
    			e.printStackTrace();//methodos g entopismo sfalmatos ston kwdika
    		}   
    		System.out.print("Enter Buyer user email: ");
    		try {
    			String usemail = input.readLine();
    		} catch (IOException e) {
    			e.printStackTrace();
    		} 
    		System.out.print("Enter Buyer bonus: ");
    		try {
    			int bonus = Integer.parseInt(input.readLine());
    		} catch (NumberFormatException e) {
    			e.printStackTrace();
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
        
        
    		if (buyerAlreadyExists=true)//elegxos g to an yparxei hdh o xrhsths,h afairesh tou ginetai kateutheian
    			buyersList.remove(buyer);
    		else
    			System.out.println("This buyer does not exist,can not remove !");
    		if(b != null)
    			buyersList.remove(b);
    }   
        
     public void updateItemStock() throws Exception
     {
    	 for(Item item : itemsList) {
            int a;
            BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Give me the ID of the desired product");
            int scan = Integer.parseInt(input.readLine());
           
            if(scan == item.getid()){
                System.out.println("The current stock is: "+item.getstock());
                System.out.println("Type the new Stock: ");
                a=sc.nextInt();
                item.setstock(a);
            }
            else{
                System.out.println("Desired item not found");
            }
    	 }
     }
        
        public void showCategories(){
        System.out.println(" ");
        System.out.println("Our store currently has: ");
        if(pens !=0)
            System.out.println("Pens ");
        if(pencils !=0)
            System.out.println("Pencils ");    
        if(notebooks !=0)
            System.out.println("Notebooks ");
        if(papers !=0)
            System.out.println("Papers ");
    
    }
    
    public void showProductsInCategory(){
            Scanner sc = new Scanner(System.in);
            System.out.println("What kind of product do you want to see?");
            System.out.println("Press 1 for Pen("+pens+")");
            System.out.println("Press 2 for Pencil("+pencils+")");
            System.out.println("Press 3 for Notebook("+notebooks+")");
            System.out.println("Press 4 for Paper ("+papers+")");
            System.out.println(" ");
            String cat = sc.nextLine();
            
            
            switch(cat){
               case"1":
               
                   System.out.println("Pens:");
                   for (Item item: pensList) {
                		   counter++;
                		   System.out.println("\n \n ITEM NUMBER: "+counter+" \n"+item.getName()+"\nID: "+item.getid());

                    }
                    break;
               case"2":
               
                   System.out.println("Pencils:");
                   for (Item item: pencilsList) {
                	   	   counter++;
                		   System.out.println("\n \n ITEM NUMBER: "+counter+" \n"+item.getName()+"\nID: "+item.getid());

                    }
                    break;
               case"3":
               
                   System.out.println("Notebooks:");
                   for (Item item: notebooksList) {
                	   if(item instanceof Notebook)
                		   System.out.println("\n \n ITEM NUMBER: "+counter+" \n"+item.getName()+"\nID: "+item.getid());

                    }
                    break;
               case"4":
               
                   System.out.println("Papers:");
                   for (Item item: papersList) {
                	   if(item instanceof Paper)
                		   System.out.println("\n \n ITEM NUMBER: "+counter+" \n"+item.getName()+"\nID: "+item.getid());

                    }
                    break;
               default:
               System.out.println("Sorry, wrong type!");
            }
        }
        
    public void showProduct() throws Exception
    {
        for (Item item : itemsList)
            getItemById();
    }
      
    public void checkStatus() throws Exception 
    {
        for (User b1 : buyersList) {
            System.out.println("Oi buyers einai:"+getbuyersList());
        	System.out.println("Buyers: \n" + b1.userinfo());
            
        }
            
    }
}
