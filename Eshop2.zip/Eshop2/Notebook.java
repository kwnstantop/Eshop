public class Notebook extends Item//h klash notebook klironomei thn klasi Item
{
    protected int sections;//arithmos thematwn tou Notebook
    
    //dimiourgos tis Notebook
    public Notebook(String name,double price,String description,int stock,int id,int s)
    {
       super(name,price,description,stock,id);
       sections=s;
    }
    
    public String getDetails()//polimorfismos:orizoume diaforetika thn  getDetails() ap oti stis alles ipoklaseis tis Item
    {
        return " O arithmos thematwn tou tetradiou einai:"+sections;
    }
}
