public class ItemOrdered
{
    //extend thn eshop kai super thn arrayist
    private Item item;
    int quantity;//posothta enos proiontos se mia paraggelia
    private int ordid;//kwdikos paraggelias

    //kenos constructor tis ItemOrdered
    public ItemOrdered() {
        
    }
    //ItemOrdered constructor
    public ItemOrdered(Item item, int quantity) {
        this.item = item;
        this.quantity=quantity;
    }

    
    public void setQuantity(int quantity) {
        this.quantity=quantity;
    }
    public void setordId(int ordid) {
        this.ordid= ordid;
    }
    public int getordId() {
        return ordid;
    }
    public int  getQuantity() {
        return quantity;
    }
    public Item getItem() {
        return item;
    }
    public int getItemId() {
        return item.getid();
    }

    public void setItem(Item item) {
        this.item = item;
    }

    @Override
    public String toString()//epistrefei ws String message to item ths paraggelias,thn posothta tou kai ton kwdiko tou 
    {
        return " Item: " + item +",Quantity: " + quantity +",Order id: "+ ordid;
    }
}
